import pygame
import sys
import math


pygame.init()


WIDTH, HEIGHT = 600, 600
WINDOW_SIZE = (WIDTH, HEIGHT)
RADIUS = 150
NUM_SIDES = 9
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
LINE_WIDTH = 6
YELLOW = (255, 255, 0)

def draw_nonagon(window):
    side_length = 2 * RADIUS * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        x = WIDTH // 2 + RADIUS * math.cos(i * angle)
        y = HEIGHT // 2 + RADIUS * math.sin(i * angle)
        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)



def draw_rotated_nonagon(window, angle_offset, scale):
    side_length = 2 * RADIUS * scale * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        x = WIDTH // 2 + RADIUS * scale * math.cos(i * angle + math.radians(angle_offset))
        y = HEIGHT // 2 + RADIUS * scale * math.sin(i * angle + math.radians(angle_offset))
        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)



def draw_scaled_nonagon(window, scale):
    side_length = 2 * RADIUS * scale * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        x = WIDTH // 2 + RADIUS * scale * math.cos(i * angle)
        y = HEIGHT // 2 + RADIUS * scale * math.sin(i * angle)
        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)



def draw_adjusted_nonagon(window):
    side_length = 2 * RADIUS * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):

        if i == 0 or i == 4:
            x = WIDTH // 2 + (RADIUS * math.cos(i * angle)) - (RADIUS * 0.25)
            y = HEIGHT // 2 + (RADIUS * math.sin(i * angle)) - (RADIUS * 0.25)
        else:

            x = WIDTH // 2 + RADIUS * math.cos(i * angle)
            y = HEIGHT // 2 + RADIUS * math.sin(i * angle)

        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)



def draw_wide_nonagon(window):
    scale = 0.75
    angle_offset = 45
    side_length = 4 * RADIUS * scale * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        x = WIDTH // 2 + 2 * RADIUS * scale * math.cos(i * angle + math.radians(-angle_offset))
        y = RADIUS * scale + RADIUS * scale * math.sin(i * angle + math.radians(-angle_offset)) + 10
        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)

def draw_sixth_shape(window):
    side_length = 2 * RADIUS * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):

        if i == 0 or i == 4:
            x = WIDTH // 2 + (RADIUS * math.cos(i * angle)) - (RADIUS * 0.25)
            y = HEIGHT // 2 + (RADIUS * math.sin(i * angle)) - (RADIUS * 0.25)
        else:

            x = WIDTH // 2 + RADIUS * math.cos(i * angle)
            y = HEIGHT // 2 + RADIUS * math.sin(i * angle)

        points.append((x, y))


    rotation_angle = math.radians(90)
    rotated_points = []
    for point in points:
        x_rotated = WIDTH // 2 + (point[0] - WIDTH // 2) * math.cos(rotation_angle) - (point[1] - HEIGHT // 2) * math.sin(rotation_angle)
        y_rotated = HEIGHT // 2 + (point[0] - WIDTH // 2) * math.sin(rotation_angle) + (point[1] - HEIGHT // 2) * math.cos(rotation_angle)
        rotated_points.append((x_rotated, y_rotated))

    pygame.draw.polygon(window, BLUE, rotated_points, 0)
    pygame.draw.polygon(window, BLACK, rotated_points, LINE_WIDTH)






# Function to draw the seventh shape
def draw_seventh_shape(window):
    scale = 1.0625  # Scale factor
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        x = WIDTH // 2 - RADIUS * scale * math.cos(i * angle)  # Horizontally reversed
        y = HEIGHT // 2 + RADIUS * scale * math.sin(i * angle)
        points.append((x, y))

    pygame.draw.polygon(window, BLUE, points, 0)  # Fill nonagon with blue
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)  # Add black outline





# Function to draw the eighth shape (copy of the fifth shape)
def draw_eighth_shape(window):
    scale = 0.75
    rotation_angle = math.radians(45)  # Rotation angle of 45 degrees counterclockwise
    side_length = 4 * RADIUS * scale * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        # Coordinates before rotation
        x_before = WIDTH // 2 + 2 * RADIUS * scale * math.cos(angle * i)
        y_before = RADIUS * scale + RADIUS * scale * math.sin(angle * i) + 300  # Move down by 190 pixels

        # Apply rotation to each vertex
        x = WIDTH // 2 + (x_before - WIDTH // 2) * math.cos(rotation_angle) - (y_before - RADIUS * scale) * math.sin(rotation_angle)
        y = RADIUS * scale + (x_before - WIDTH // 2) * math.sin(rotation_angle) + (y_before - RADIUS * scale) * math.cos(rotation_angle)

        points.append((x, y))

    # Calculate the current center of the shape
    center_x = sum(point[0] for point in points) / len(points)

    # Calculate the adjustment needed to move the shape to the right
    x_adjustment = WIDTH // 2 + 10- center_x

    # Adjust all the x-coordinates of the vertices
    points = [(x + x_adjustment, y) for x, y in points]

    pygame.draw.polygon(window, BLUE, points, 0)  # Fill nonagon with blue
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)  # Add black outline


# Function to draw the ninth shape (copy of the sixth shape)
def draw_ninth_shape(window):
    side_length = 2 * RADIUS * math.cos(math.pi / NUM_SIDES)
    angle = (2 * math.pi) / NUM_SIDES

    points = []
    for i in range(NUM_SIDES):
        # Calculate the coordinates of the vertices
        if i == 0 or i == 4:  # Index of the upper left and lower right vertices
            x = WIDTH // 2 + (RADIUS * math.cos(i * angle)) + (RADIUS * 0.25)  # Move right
            y = HEIGHT // 2 + (RADIUS * math.sin(i * angle)) + (RADIUS * 0.25)  # Move down
        else:
            # Calculate the coordinates of other vertices normally
            x = WIDTH // 2 + RADIUS * math.cos(i * angle)
            y = HEIGHT // 2 + RADIUS * math.sin(i * angle)

        points.append((x, y))

    # Reverse the order of points to rotate by 180 degrees
    points.reverse()

    pygame.draw.polygon(window, BLUE, points, 0)  # Fill nonagon with blue
    pygame.draw.polygon(window, BLACK, points, LINE_WIDTH)  # Add black outline









# Main function
def main():
    # Create window
    window = pygame.display.set_mode(WINDOW_SIZE)
    pygame.display.set_caption("Drawing Shapes")

    # Current shape to be drawn
    current_shape = None

    # Main loop
    while True:
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Clear the screen
        window.fill(YELLOW)

        # Check for key presses
        keys = pygame.key.get_pressed()
        if keys[pygame.K_1]:
            current_shape = lambda: draw_nonagon(window)  # Nonagon
        elif keys[pygame.K_2]:
            current_shape = lambda: draw_rotated_nonagon(window, 45, 1.5)  # Rotated nonagon scaled 1.5 times
        elif keys[pygame.K_3]:
            current_shape = lambda: draw_scaled_nonagon(window, 1.0625)  # Scaled nonagon (laid vertically)
        elif keys[pygame.K_4]:
            current_shape = lambda: draw_adjusted_nonagon(window)  # Adjusted nonagon
        elif keys[pygame.K_5]:
            current_shape = lambda: draw_wide_nonagon(window)  # Twice as wide nonagon at the top center
        elif keys[pygame.K_6]:
            current_shape = lambda: draw_sixth_shape(window)  # Sixth shape
        elif keys[pygame.K_7]:
            current_shape = lambda: draw_seventh_shape(window)  # Seventh shape
        elif keys[pygame.K_8]:
            current_shape = lambda: draw_eighth_shape(window)  # Eighth shape
        elif keys[pygame.K_9]:
            current_shape = lambda: draw_ninth_shape(window)  # Nighth shape

        # Draw the selected shape
        if current_shape:
            current_shape()

        # Refresh the screen
        pygame.display.flip()


# Run the main function
if __name__ == "__main__":
    main()
